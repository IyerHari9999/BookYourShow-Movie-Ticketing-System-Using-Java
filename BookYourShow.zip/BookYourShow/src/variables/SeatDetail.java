package variables;
public class SeatDetail
{
    static String seat;
    public SeatDetail()
    {}
    public SeatDetail(String s)
    {
        seat=s;
        System.out.println(seat);
    }
    public String getSeatDetail()
    {
    return seat;
    }
}
