package variables;
public class DateT 
{
    static String datetime;
    public DateT()
    {}
    public DateT(String s)
    {
       datetime=s;
       System.out.println(datetime);
    }
    public String getDateT()
    {
    return datetime;
    }
}
