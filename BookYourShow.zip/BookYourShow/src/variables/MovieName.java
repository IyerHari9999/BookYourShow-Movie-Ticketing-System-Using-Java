package variables;
public class MovieName 
{
    static String movie;
    public MovieName()
    {
    }
    public MovieName(String s)
    {
        movie=s;
        System.out.println(movie);
    }
    public String getMovieName()
    {
    return movie;
    }
}
