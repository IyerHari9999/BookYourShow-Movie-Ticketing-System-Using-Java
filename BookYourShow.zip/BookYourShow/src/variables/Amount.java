package variables;
public class Amount 
{
    static int r;
    public Amount()
    {}
    public Amount(int s)
    {
        r=s;
        System.out.println(r);
    }
    public String getAmount()
    {
    return (""+r);
    }
}
