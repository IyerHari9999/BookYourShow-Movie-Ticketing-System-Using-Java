package variables;
public class Theater 
{
    static String theater;
    public Theater()
    {}
    public Theater(String s)
    {
        theater=s;
        System.out.println(theater);
    }
    public String getTheater()
    {
    return theater;
    }
}
